//! Miscellaneous helper types and functions used throughout the
//! library.  These helpers are not exposed publicly but assist the
//! various modules in dealing with asynchronous udev streams and
//! stream combinators.

pub(crate) mod udev;
pub(crate) mod scan;