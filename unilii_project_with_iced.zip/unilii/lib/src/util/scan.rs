// This module copies the `Scan` stream combinator from
// `futures-util`.  At the time of writing the original `scan`
// implementation in `futures-util` was gated behind the `alloc`
// feature and not yet stable.  The `liischte` project included its
// own copy, which we reproduce here to maintain compatibility.  See
// https://github.com/rust-lang/futures-rs/issues/2171 for discussion.

use core::fmt;
use core::pin::Pin;
use futures_core::future::Future;
use futures_core::ready;
use futures_core::stream::Stream;
use futures_core::task::{Context, Poll};
use pin_project_lite::pin_project;

pin_project! {
    /// Internal state for the `scan` combinator.  This enum tracks
    /// whether we currently have a future in flight or a value ready
    /// to be passed to the scanning function.
    #[derive(Debug)]
    pub(crate) enum UnfoldState<T, Fut> {
        /// A value that has not yet been passed into the scanning
        /// function.
        Value { value: T },
        /// A future returned from the scanning function which has not
        /// yet been resolved.
        Future { #[pin] future: Fut },
        /// The scan is finished.
        Empty,
    }
}

impl<T, Fut> UnfoldState<T, Fut> {
    fn is_empty(&self) -> bool {
        matches!(self, Self::Empty)
    }
    fn project_future(self: Pin<&mut Self>) -> Option<Pin<&mut Fut>> {
        match self.project() {
            UnfoldStateProj::Future { future } => Some(future),
            _ => None,
        }
    }
    fn take_value(self: Pin<&mut Self>) -> Option<T> {
        match &*self {
            Self::Value { .. } => match self.project_replace(Self::Empty) {
                UnfoldStateProjReplace::Value { value } => Some(value),
                _ => unreachable!(),
            },
            _ => None,
        }
    }
}

pin_project! {
    /// A stream produced by the `scan` combinator.  Each item of the
    /// underlying stream is passed through a scanning function along with
    /// some state.  The scanning function returns a future which yields
    /// an optional new state and item.  When the scanning function
    /// returns `None` the stream terminates.
    #[must_use = "streams do nothing unless polled"]
    pub struct ScanOwning<St: Stream, S, Fut, F> {
        #[pin]
        stream: St,
        f: F,
        #[pin]
        state: UnfoldState<S, Fut>,
    }
}

impl<B, St, S, Fut, F> ScanOwning<St, S, Fut, F>
where
    St: Stream,
    F: FnMut(S, St::Item) -> Fut,
    Fut: Future<Output = Option<(S, B)>>,
{
    pub(super) fn new(stream: St, initial_state: S, f: F) -> Self {
        Self { stream, f, state: UnfoldState::Value { value: initial_state } }
    }
}

impl<B, St, S, Fut, F> Stream for ScanOwning<St, S, Fut, F>
where
    St: Stream,
    F: FnMut(S, St::Item) -> Fut,
    Fut: Future<Output = Option<(S, B)>>,
{
    type Item = B;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<B>> {
        if self.state.is_empty() {
            return Poll::Ready(None);
        }
        let mut this = self.project();
        Poll::Ready(loop {
            if let Some(fut) = this.state.as_mut().project_future() {
                match ready!(fut.poll(cx)) {
                    None => {
                        this.state.set(UnfoldState::Empty);
                        break None;
                    }
                    Some((state, item)) => {
                        this.state.set(UnfoldState::Value { value: state });
                        break Some(item);
                    }
                }
            } else if let Some(item) = ready!(this.stream.as_mut().poll_next(cx)) {
                let state = this.state.as_mut().take_value().unwrap();
                this.state.set(UnfoldState::Future { future: (this.f)(state, item) });
            } else {
                break None;
            }
        })
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.state.is_empty() {
            (0, Some(0))
        } else {
            self.stream.size_hint()
        }
    }
}